module.exports = require('../../jest.config.js');
